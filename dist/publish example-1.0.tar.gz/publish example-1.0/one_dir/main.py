class Sample:
    def __init__(self):
        print('Sample')
